-- Migration number: 0001 	 2025-03-19
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS organizations;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS donations;
DROP TABLE IF EXISTS subscriptions;
DROP TABLE IF EXISTS payouts;
DROP TABLE IF EXISTS campaigns;
DROP TABLE IF EXISTS webhooks;
DROP TABLE IF EXISTS activity_logs;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  role TEXT NOT NULL CHECK (role IN ('donor', 'organization_admin', 'platform_admin')),
  profile_image TEXT,
  phone_number TEXT,
  street_address TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  country TEXT,
  email_notifications BOOLEAN DEFAULT TRUE,
  newsletter_subscribed BOOLEAN DEFAULT FALSE,
  donation_receipts BOOLEAN DEFAULT TRUE,
  stripe_customer_id TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at DATETIME
);

-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  mission TEXT,
  logo TEXT,
  cover_image TEXT,
  website TEXT,
  email TEXT NOT NULL,
  phone_number TEXT,
  street_address TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  country TEXT,
  facebook_url TEXT,
  twitter_url TEXT,
  instagram_url TEXT,
  linkedin_url TEXT,
  tax_id TEXT,
  verification_status TEXT NOT NULL CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  stripe_connected_account_id TEXT,
  payout_schedule TEXT CHECK (payout_schedule IN ('daily', 'weekly', 'monthly')),
  featured_rank INTEGER,
  total_donations REAL DEFAULT 0,
  total_donors INTEGER DEFAULT 0,
  recurring_donors INTEGER DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  parent_category_id INTEGER,
  is_active BOOLEAN DEFAULT TRUE,
  display_order INTEGER,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_category_id) REFERENCES categories(id)
);

-- Organization Categories (many-to-many)
CREATE TABLE IF NOT EXISTS organization_categories (
  organization_id INTEGER NOT NULL,
  category_id INTEGER NOT NULL,
  PRIMARY KEY (organization_id, category_id),
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Organization Admins (many-to-many)
CREATE TABLE IF NOT EXISTS organization_admins (
  organization_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  PRIMARY KEY (organization_id, user_id),
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Donations table
CREATE TABLE IF NOT EXISTS donations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  donor_id INTEGER,
  organization_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  payment_method_type TEXT,
  payment_method_last4 TEXT,
  stripe_payment_intent_id TEXT,
  stripe_transfer_id TEXT,
  platform_fee REAL,
  stripe_fee REAL,
  cover_fees BOOLEAN DEFAULT FALSE,
  is_anonymous BOOLEAN DEFAULT FALSE,
  is_recurring BOOLEAN DEFAULT FALSE,
  subscription_id INTEGER,
  note TEXT,
  receipt_sent BOOLEAN DEFAULT FALSE,
  receipt_url TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES users(id),
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (subscription_id) REFERENCES subscriptions(id)
);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  donor_id INTEGER NOT NULL,
  organization_id INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'canceled', 'failed')),
  amount REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  interval TEXT NOT NULL CHECK (interval IN ('monthly', 'quarterly', 'annually')),
  start_date DATETIME NOT NULL,
  next_billing_date DATETIME NOT NULL,
  canceled_at DATETIME,
  stripe_subscription_id TEXT,
  payment_method_type TEXT,
  payment_method_last4 TEXT,
  platform_fee REAL,
  stripe_fee REAL,
  cover_fees BOOLEAN DEFAULT FALSE,
  is_anonymous BOOLEAN DEFAULT FALSE,
  failed_payments INTEGER DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES users(id),
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

-- Payouts table
CREATE TABLE IF NOT EXISTS payouts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  organization_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL CHECK (status IN ('pending', 'completed', 'failed')),
  stripe_payout_id TEXT,
  period_start DATETIME NOT NULL,
  period_end DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

-- Payout Donations (many-to-many)
CREATE TABLE IF NOT EXISTS payout_donations (
  payout_id INTEGER NOT NULL,
  donation_id INTEGER NOT NULL,
  PRIMARY KEY (payout_id, donation_id),
  FOREIGN KEY (payout_id) REFERENCES payouts(id),
  FOREIGN KEY (donation_id) REFERENCES donations(id)
);

-- Campaigns table
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  organization_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  description TEXT,
  goal REAL,
  currency TEXT NOT NULL DEFAULT 'USD',
  start_date DATETIME NOT NULL,
  end_date DATETIME,
  is_active BOOLEAN DEFAULT TRUE,
  cover_image TEXT,
  total_raised REAL DEFAULT 0,
  total_donors INTEGER DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  UNIQUE (organization_id, slug)
);

-- Campaign Media
CREATE TABLE IF NOT EXISTS campaign_media (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('image', 'video')),
  url TEXT NOT NULL,
  caption TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
);

-- Webhooks table
CREATE TABLE IF NOT EXISTS webhooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  event TEXT NOT NULL,
  payload TEXT NOT NULL,
  processed BOOLEAN DEFAULT FALSE,
  processing_errors TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME
);

-- Activity Logs table
CREATE TABLE IF NOT EXISTS activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id INTEGER,
  details TEXT,
  ip_address TEXT,
  user_agent TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_stripe_customer_id ON users(stripe_customer_id);
CREATE INDEX idx_organizations_slug ON organizations(slug);
CREATE INDEX idx_organizations_verification_status ON organizations(verification_status);
CREATE INDEX idx_categories_slug ON categories(slug);
CREATE INDEX idx_donations_donor_id ON donations(donor_id);
CREATE INDEX idx_donations_organization_id ON donations(organization_id);
CREATE INDEX idx_donations_created_at ON donations(created_at);
CREATE INDEX idx_donations_status ON donations(status);
CREATE INDEX idx_subscriptions_donor_id ON subscriptions(donor_id);
CREATE INDEX idx_subscriptions_organization_id ON subscriptions(organization_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_subscriptions_next_billing_date ON subscriptions(next_billing_date);
CREATE INDEX idx_campaigns_organization_id ON campaigns(organization_id);
CREATE INDEX idx_campaigns_is_active ON campaigns(is_active);
CREATE INDEX idx_payouts_organization_id ON payouts(organization_id);
CREATE INDEX idx_payouts_status ON payouts(status);
CREATE INDEX idx_webhooks_source_event ON webhooks(source, event);
CREATE INDEX idx_webhooks_processed ON webhooks(processed);
CREATE INDEX idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX idx_activity_logs_created_at ON activity_logs(created_at);

-- Insert initial categories
INSERT INTO categories (name, slug, description, icon, is_active, display_order) VALUES 
  ('Education', 'education', 'Educational initiatives and institutions', 'school', TRUE, 1),
  ('Health', 'health', 'Health and medical causes', 'heart-pulse', TRUE, 2),
  ('Environment', 'environment', 'Environmental conservation and sustainability', 'leaf', TRUE, 3),
  ('Humanitarian', 'humanitarian', 'Humanitarian aid and disaster relief', 'users', TRUE, 4),
  ('Animal Welfare', 'animal-welfare', 'Animal protection and welfare', 'paw', TRUE, 5),
  ('Arts & Culture', 'arts-culture', 'Arts, culture, and heritage preservation', 'palette', TRUE, 6),
  ('Community Development', 'community-development', 'Local community development projects', 'building-community', TRUE, 7),
  ('Human Rights', 'human-rights', 'Human rights advocacy and protection', 'scale', TRUE, 8);

-- Insert platform admin user
INSERT INTO users (email, password_hash, first_name, last_name, role, created_at, updated_at) VALUES 
  ('admin@donationplatform.com', '$2a$12$1234567890123456789012uGZACxF5WBI6N9AY.cet0cBodRa78.S', 'Platform', 'Admin', 'platform_admin', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
