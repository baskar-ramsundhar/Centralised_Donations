# Environment Variables Configuration

Create a `.env.local` file in the root of your project with the following variables:

```
# App
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Database
MONGODB_URI=mongodb://localhost:27017/donation-platform

# Authentication
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-nextauth-secret-key-here

# Stripe
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_publishable_key
STRIPE_WEBHOOK_SECRET=whsec_your_stripe_webhook_secret

# Email (optional)
EMAIL_SERVER=smtp://username:password@smtp.example.com:587
EMAIL_FROM=noreply@donationplatform.com
```

Replace the placeholder values with your actual configuration details. For development, you can use test keys from Stripe.

Note: Never commit this file to version control. It's already included in .gitignore by default.
