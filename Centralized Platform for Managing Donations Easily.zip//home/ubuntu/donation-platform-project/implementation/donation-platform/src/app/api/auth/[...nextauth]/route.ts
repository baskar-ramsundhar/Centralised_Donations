import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { getUserByEmail } from '@/lib/db';
import { compare } from 'bcrypt';

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        // Get D1 database instance from environment
        const { DB } = req.env as { DB: D1Database };
        
        // Find user by email
        const user = await getUserByEmail(DB, credentials.email);
        
        if (!user) {
          return null;
        }
        
        // Verify password
        const isValidPassword = await compare(credentials.password, user.password_hash);
        
        if (!isValidPassword) {
          return null;
        }
        
        // Update last login timestamp
        await DB.prepare(
          'UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?'
        ).bind(user.id).run();
        
        return {
          id: user.id.toString(),
          email: user.email,
          name: `${user.first_name || ''} ${user.last_name || ''}`.trim(),
          role: user.role,
          image: user.profile_image || null
        };
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
      }
      return token;
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id;
        session.user.role = token.role;
      }
      return session;
    }
  },
  pages: {
    signIn: '/auth/signin',
    signOut: '/auth/signout',
    error: '/auth/error',
  },
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
