'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

// Mock data for organization dashboard
const MOCK_ORGANIZATION = {
  id: 1,
  name: 'Global Water Foundation',
  slug: 'global-water-foundation',
  description: 'Providing clean water access to communities around the world.',
  mission: 'Our mission is to ensure that every person on the planet has access to clean, safe drinking water.',
  logo: '/placeholder.png',
  coverImage: '/placeholder.png',
  website: 'https://example.org',
  email: 'contact@example.org',
  phoneNumber: '+1 (555) 123-4567',
  totalDonations: 125000,
  totalDonors: 1250,
  recurringDonors: 450,
  verificationStatus: 'verified',
  stripeConnectedAccountId: 'acct_123456789',
  payoutSchedule: 'weekly',
};

const MOCK_DONATIONS = [
  {
    id: 1,
    donorName: 'John Smith',
    donorEmail: 'john.smith@example.com',
    amount: 25.00,
    date: '2025-03-15',
    status: 'completed',
    isRecurring: false,
    isAnonymous: false,
  },
  {
    id: 2,
    donorName: 'Anonymous',
    donorEmail: 'anonymous@example.com',
    amount: 50.00,
    date: '2025-03-10',
    status: 'completed',
    isRecurring: true,
    isAnonymous: true,
  },
  {
    id: 3,
    donorName: 'Sarah Johnson',
    donorEmail: 'sarah.johnson@example.com',
    amount: 15.00,
    date: '2025-03-05',
    status: 'completed',
    isRecurring: false,
    isAnonymous: false,
  },
  {
    id: 4,
    donorName: 'Michael Chen',
    donorEmail: 'michael.chen@example.com',
    amount: 100.00,
    date: '2025-03-01',
    status: 'completed',
    isRecurring: true,
    isAnonymous: false,
  },
];

const MOCK_PAYOUTS = [
  {
    id: 1,
    amount: 1250.00,
    date: '2025-03-15',
    status: 'completed',
    periodStart: '2025-03-08',
    periodEnd: '2025-03-14',
  },
  {
    id: 2,
    amount: 980.00,
    date: '2025-03-08',
    status: 'completed',
    periodStart: '2025-03-01',
    periodEnd: '2025-03-07',
  },
  {
    id: 3,
    amount: 1450.00,
    date: '2025-03-01',
    status: 'completed',
    periodStart: '2025-02-22',
    periodEnd: '2025-02-28',
  },
];

export default function OrganizationDashboardPage() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full mr-4"></div>
            <div>
              <h1 className="text-2xl font-bold">{MOCK_ORGANIZATION.name}</h1>
              <p className="text-sm text-gray-500">Organization Dashboard</p>
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="md:w-1/4">
            <div className="bg-white rounded-lg shadow-md p-6">
              <nav className="space-y-1">
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeTab === 'overview' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setActiveTab('overview')}
                >
                  Overview
                </button>
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeTab === 'donations' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setActiveTab('donations')}
                >
                  Donations
                </button>
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeTab === 'donors' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setActiveTab('donors')}
                >
                  Donors
                </button>
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeTab === 'payouts' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setActiveTab('payouts')}
                >
                  Payouts
                </button>
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeTab === 'settings' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setActiveTab('settings')}
                >
                  Organization Settings
                </button>
              </nav>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <Button asChild className="w-full mb-2">
                  <Link href={`/organizations/${MOCK_ORGANIZATION.slug}`}>
                    View Public Profile
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/dashboard/organization/embed">
                    Get Donation Button
                  </Link>
                </Button>
              </div>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="md:w-3/4">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-2">Total Donations</h3>
                    <p className="text-3xl font-bold text-blue-600">${(MOCK_ORGANIZATION.totalDonations / 1000).toFixed(1)}K</p>
                    <p className="text-sm text-gray-500 mt-1">All time</p>
                  </div>
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-2">Total Donors</h3>
                    <p className="text-3xl font-bold text-blue-600">{MOCK_ORGANIZATION.totalDonors}</p>
                    <p className="text-sm text-gray-500 mt-1">{MOCK_ORGANIZATION.recurringDonors} recurring</p>
                  </div>
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-2">This Month</h3>
                    <p className="text-3xl font-bold text-blue-600">$3,250</p>
                    <p className="text-sm text-gray-500 mt-1">From 45 donations</p>
                  </div>
                </div>
                
                {/* Donation Chart */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-lg font-semibold mb-4">Donation Trends</h3>
                  <div className="h-64 bg-gray-100 rounded flex items-center justify-center">
                    <p className="text-gray-500">Donation chart will be displayed here</p>
                  </div>
                </div>
                
                {/* Recent Donations */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Recent Donations</h3>
                    <Button variant="outline" size="sm" onClick={() => setActiveTab('donations')}>
                      View All
                    </Button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Donor
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Amount
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Type
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {MOCK_DONATIONS.slice(0, 5).map((donation) => (
                          <tr key={donation.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {donation.isAnonymous ? 'Anonymous' : donation.donorName}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              ${donation.amount.toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {new Date(donation.date).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {donation.isRecurring ? (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                  Recurring
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                  One-time
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'donations' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold mb-6">Donations</h2>
                
                {/* Filters */}
                <div className="flex flex-wrap gap-4 mb-6">
                  <div>
                    <label htmlFor="dateRange" className="block text-sm font-medium text-gray-700 mb-1">
                      Date Range
                    </label>
                    <select
                      id="dateRange"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="all">All Time</option>
                      <option value="thisMonth">This Month</option>
                      <option value="lastMonth">Last Month</option>
                      <option value="thisYear">This Year</option>
                      <option value="custom">Custom Range</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="donationType" className="block text-sm font-medium text-gray-700 mb-1">
                      Donation Type
                    </label>
                    <select
                      id="donationType"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="all">All Types</option>
                      <option value="oneTime">One-time</option>
                      <option value="recurring">Recurring</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="sortBy" className="block text-sm font-medium text-gray-700 mb-1">
                      Sort By
                    </label>
                    <select
                      id="sortBy"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="dateDesc">Date (Newest First)</option>
                      <option value="dateAsc">Date (Oldest First)</option>
                      <option value="amountDesc">Amount (Highest First)</option>
                      <option value="amountAsc">Amount (Lowest First)</option>
                    </select>
                  </div>
                </div>
                
                {/* Donations Table */}
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Donor
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Type
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {MOCK_DONATIONS.map((donation) => (
                        <tr key={donation.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {donation.isAnonymous ? 'Anonymous' : donation.donorName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {donation.isAnonymous ? '—' : donation.donorEmail}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            ${donation.amount.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {new Date(donation.date).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {donation.isRecurring ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                Recurring
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                One-time
                              </span>
                            )}
                          </t<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>