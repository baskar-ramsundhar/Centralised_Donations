import { Stripe } from 'stripe';

// Initialize Stripe with the secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2024-03-19', // Use the latest API version
});

/**
 * Create a Stripe customer
 * @param email Customer email
 * @param name Customer name
 * @param metadata Additional metadata
 */
export async function createCustomer(email: string, name?: string, metadata?: Record<string, string>) {
  return stripe.customers.create({
    email,
    name,
    metadata,
  });
}

/**
 * Create a Stripe Connect account for an organization
 * @param email Organization email
 * @param businessName Organization name
 * @param country Country code (default: 'US')
 * @param metadata Additional metadata
 */
export async function createConnectedAccount(
  email: string,
  businessName: string,
  country = 'US',
  metadata?: Record<string, string>
) {
  return stripe.accounts.create({
    type: 'express',
    country,
    email,
    business_type: 'non_profit',
    business_profile: {
      name: businessName,
      url: metadata?.website,
    },
    capabilities: {
      card_payments: { requested: true },
      transfers: { requested: true },
    },
    metadata,
  });
}

/**
 * Generate an account link for onboarding
 * @param accountId Stripe account ID
 * @param refreshUrl URL to redirect on refresh
 * @param returnUrl URL to redirect on completion
 */
export async function createAccountLink(accountId: string, refreshUrl: string, returnUrl: string) {
  return stripe.accountLinks.create({
    account: accountId,
    refresh_url: refreshUrl,
    return_url: returnUrl,
    type: 'account_onboarding',
  });
}

/**
 * Create a payment intent for a one-time donation
 * @param amount Amount in cents
 * @param currency Currency code
 * @param customerId Stripe customer ID
 * @param metadata Additional metadata
 */
export async function createPaymentIntent(
  amount: number,
  currency: string,
  customerId: string,
  metadata?: Record<string, string>
) {
  return stripe.paymentIntents.create({
    amount,
    currency,
    customer: customerId,
    metadata,
    payment_method_types: ['card'],
  });
}

/**
 * Create a destination charge and transfer funds to connected account
 * @param amount Amount in cents
 * @param currency Currency code
 * @param customerId Stripe customer ID
 * @param destinationAccountId Connected account ID
 * @param applicationFeeAmount Platform fee amount in cents
 * @param metadata Additional metadata
 */
export async function createDestinationCharge(
  amount: number,
  currency: string,
  customerId: string,
  destinationAccountId: string,
  applicationFeeAmount: number,
  metadata?: Record<string, string>
) {
  return stripe.paymentIntents.create({
    amount,
    currency,
    customer: customerId,
    transfer_data: {
      destination: destinationAccountId,
    },
    application_fee_amount: applicationFeeAmount,
    metadata,
    payment_method_types: ['card'],
  });
}

/**
 * Create a subscription for recurring donations
 * @param customerId Stripe customer ID
 * @param priceId Stripe price ID
 * @param paymentMethodId Payment method ID
 * @param destinationAccountId Connected account ID (for destination charges)
 * @param applicationFeePercent Platform fee percentage
 * @param metadata Additional metadata
 */
export async function createSubscription(
  customerId: string,
  priceId: string,
  paymentMethodId: string,
  destinationAccountId?: string,
  applicationFeePercent?: number,
  metadata?: Record<string, string>
) {
  const subscriptionData: Stripe.SubscriptionCreateParams = {
    customer: customerId,
    items: [{ price: priceId }],
    default_payment_method: paymentMethodId,
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent'],
    metadata,
  };

  // Add transfer data for destination charges
  if (destinationAccountId && applicationFeePercent) {
    subscriptionData.transfer_data = {
      destination: destinationAccountId,
    };
    subscriptionData.application_fee_percent = applicationFeePercent;
  }

  return stripe.subscriptions.create(subscriptionData);
}

/**
 * Create a price for recurring donations
 * @param amount Amount in cents
 * @param currency Currency code
 * @param interval Billing interval
 * @param productId Stripe product ID
 * @param metadata Additional metadata
 */
export async function createPrice(
  amount: number,
  currency: string,
  interval: 'month' | 'quarter' | 'year',
  productId: string,
  metadata?: Record<string, string>
) {
  // Convert quarter to 3 months
  const intervalCount = interval === 'quarter' ? 3 : 1;
  const billingInterval = interval === 'quarter' ? 'month' : interval;

  return stripe.prices.create({
    unit_amount: amount,
    currency,
    recurring: {
      interval: billingInterval as Stripe.PriceCreateParams.Recurring.Interval,
      interval_count: intervalCount,
    },
    product: productId,
    metadata,
  });
}

/**
 * Create a product for an organization
 * @param name Organization name
 * @param description Organization description
 * @param metadata Additional metadata
 */
export async function createProduct(
  name: string,
  description?: string,
  metadata?: Record<string, string>
) {
  return stripe.products.create({
    name,
    description,
    metadata,
  });
}

/**
 * Retrieve account balance for a connected account
 * @param accountId Connected account ID
 */
export async function getAccountBalance(accountId: string) {
  return stripe.balance.retrieve({
    stripeAccount: accountId,
  });
}

/**
 * Create a payout to a connected account
 * @param accountId Connected account ID
 * @param amount Amount in cents
 * @param currency Currency code
 * @param metadata Additional metadata
 */
export async function createPayout(
  accountId: string,
  amount: number,
  currency: string,
  metadata?: Record<string, string>
) {
  return stripe.payouts.create(
    {
      amount,
      currency,
      metadata,
    },
    {
      stripeAccount: accountId,
    }
  );
}

/**
 * Handle Stripe webhook events
 * @param payload Webhook payload
 * @param signature Stripe signature
 * @param webhookSecret Webhook secret
 */
export async function handleWebhookEvent(
  payload: string,
  signature: string,
  webhookSecret: string
) {
  try {
    const event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    return event;
  } catch (err) {
    throw new Error(`Webhook Error: ${err instanceof Error ? err.message : 'Unknown error'}`);
  }
}
