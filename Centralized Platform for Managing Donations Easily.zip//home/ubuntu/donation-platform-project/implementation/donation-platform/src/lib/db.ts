import { D1Database } from '@cloudflare/workers-types';

/**
 * Database utility functions for interacting with D1 database
 */

export async function getUserById(db: D1Database, id: number) {
  const user = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
  return user;
}

export async function getUserByEmail(db: D1Database, email: string) {
  const user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
  return user;
}

export async function createUser(db: D1Database, userData: {
  email: string;
  password_hash: string;
  first_name?: string;
  last_name?: string;
  role: string;
}) {
  const { email, password_hash, first_name, last_name, role } = userData;
  
  const result = await db.prepare(
    'INSERT INTO users (email, password_hash, first_name, last_name, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
  ).bind(email, password_hash, first_name || null, last_name || null, role).run();
  
  return result.meta.last_row_id;
}

export async function getOrganizationById(db: D1Database, id: number) {
  const organization = await db.prepare('SELECT * FROM organizations WHERE id = ?').bind(id).first();
  return organization;
}

export async function getOrganizationBySlug(db: D1Database, slug: string) {
  const organization = await db.prepare('SELECT * FROM organizations WHERE slug = ?').bind(slug).first();
  return organization;
}

export async function getVerifiedOrganizations(db: D1Database, limit = 10, offset = 0) {
  const organizations = await db.prepare(
    'SELECT * FROM organizations WHERE verification_status = ? ORDER BY featured_rank DESC, name ASC LIMIT ? OFFSET ?'
  ).bind('verified', limit, offset).all();
  
  return organizations.results;
}

export async function getOrganizationsByCategory(db: D1Database, categoryId: number, limit = 10, offset = 0) {
  const organizations = await db.prepare(
    `SELECT o.* FROM organizations o
     JOIN organization_categories oc ON o.id = oc.organization_id
     WHERE oc.category_id = ? AND o.verification_status = ?
     ORDER BY o.featured_rank DESC, o.name ASC LIMIT ? OFFSET ?`
  ).bind(categoryId, 'verified', limit, offset).all();
  
  return organizations.results;
}

export async function createDonation(db: D1Database, donationData: {
  donor_id?: number;
  organization_id: number;
  amount: number;
  currency: string;
  status: string;
  payment_method_type?: string;
  payment_method_last4?: string;
  stripe_payment_intent_id?: string;
  stripe_transfer_id?: string;
  platform_fee?: number;
  stripe_fee?: number;
  cover_fees: boolean;
  is_anonymous: boolean;
  is_recurring: boolean;
  subscription_id?: number;
  note?: string;
}) {
  const {
    donor_id,
    organization_id,
    amount,
    currency,
    status,
    payment_method_type,
    payment_method_last4,
    stripe_payment_intent_id,
    stripe_transfer_id,
    platform_fee,
    stripe_fee,
    cover_fees,
    is_anonymous,
    is_recurring,
    subscription_id,
    note
  } = donationData;
  
  const result = await db.prepare(
    `INSERT INTO donations (
      donor_id, organization_id, amount, currency, status, 
      payment_method_type, payment_method_last4, stripe_payment_intent_id, 
      stripe_transfer_id, platform_fee, stripe_fee, cover_fees, 
      is_anonymous, is_recurring, subscription_id, note, 
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`
  ).bind(
    donor_id || null,
    organization_id,
    amount,
    currency,
    status,
    payment_method_type || null,
    payment_method_last4 || null,
    stripe_payment_intent_id || null,
    stripe_transfer_id || null,
    platform_fee || null,
    stripe_fee || null,
    cover_fees ? 1 : 0,
    is_anonymous ? 1 : 0,
    is_recurring ? 1 : 0,
    subscription_id || null,
    note || null
  ).run();
  
  return result.meta.last_row_id;
}

export async function getCategories(db: D1Database) {
  const categories = await db.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY display_order ASC, name ASC').all();
  return categories.results;
}

export async function getDonationsByOrganization(db: D1Database, organizationId: number, limit = 10, offset = 0) {
  const donations = await db.prepare(
    'SELECT * FROM donations WHERE organization_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?'
  ).bind(organizationId, limit, offset).all();
  
  return donations.results;
}

export async function getDonationsByDonor(db: D1Database, donorId: number, limit = 10, offset = 0) {
  const donations = await db.prepare(
    'SELECT * FROM donations WHERE donor_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?'
  ).bind(donorId, limit, offset).all();
  
  return donations.results;
}

export async function getSubscriptionsByDonor(db: D1Database, donorId: number) {
  const subscriptions = await db.prepare(
    'SELECT * FROM subscriptions WHERE donor_id = ? ORDER BY created_at DESC'
  ).bind(donorId).all();
  
  return subscriptions.results;
}

export async function updateSubscriptionStatus(db: D1Database, id: number, status: string) {
  const result = await db.prepare(
    'UPDATE subscriptions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
  ).bind(status, id).run();
  
  return result.success;
}
