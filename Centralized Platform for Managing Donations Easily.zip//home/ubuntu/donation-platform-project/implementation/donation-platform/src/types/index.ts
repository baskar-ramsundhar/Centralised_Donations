import { D1Database } from '@cloudflare/workers-types';

export interface Env {
  DB: D1Database;
}

// User types
export type UserRole = 'donor' | 'organization_admin' | 'platform_admin';

export interface User {
  id: number;
  email: string;
  firstName: string | null;
  lastName: string | null;
  role: UserRole;
  profileImage: string | null;
  phoneNumber: string | null;
  stripeCustomerId: string | null;
  createdAt: Date;
  updatedAt: Date;
  lastLoginAt: Date | null;
}

// Organization types
export type VerificationStatus = 'pending' | 'verified' | 'rejected';
export type PayoutSchedule = 'daily' | 'weekly' | 'monthly';

export interface Organization {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  mission: string | null;
  logo: string | null;
  coverImage: string | null;
  website: string | null;
  email: string;
  phoneNumber: string | null;
  verificationStatus: VerificationStatus;
  stripeConnectedAccountId: string | null;
  payoutSchedule: PayoutSchedule | null;
  featuredRank: number | null;
  totalDonations: number;
  totalDonors: number;
  recurringDonors: number;
  createdAt: Date;
  updatedAt: Date;
}

// Category types
export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  parentCategoryId: number | null;
  isActive: boolean;
  displayOrder: number | null;
  createdAt: Date;
  updatedAt: Date;
}

// Donation types
export type DonationStatus = 'pending' | 'completed' | 'failed' | 'refunded';

export interface Donation {
  id: number;
  donorId: number | null;
  organizationId: number;
  amount: number;
  currency: string;
  status: DonationStatus;
  paymentMethodType: string | null;
  paymentMethodLast4: string | null;
  stripePaymentIntentId: string | null;
  stripeTransferId: string | null;
  platformFee: number | null;
  stripeFee: number | null;
  coverFees: boolean;
  isAnonymous: boolean;
  isRecurring: boolean;
  subscriptionId: number | null;
  note: string | null;
  receiptSent: boolean;
  receiptUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
}

// Subscription types
export type SubscriptionStatus = 'active' | 'paused' | 'canceled' | 'failed';
export type SubscriptionInterval = 'monthly' | 'quarterly' | 'annually';

export interface Subscription {
  id: number;
  donorId: number;
  organizationId: number;
  status: SubscriptionStatus;
  amount: number;
  currency: string;
  interval: SubscriptionInterval;
  startDate: Date;
  nextBillingDate: Date;
  canceledAt: Date | null;
  stripeSubscriptionId: string | null;
  paymentMethodType: string | null;
  paymentMethodLast4: string | null;
  platformFee: number | null;
  stripeFee: number | null;
  coverFees: boolean;
  isAnonymous: boolean;
  failedPayments: number;
  createdAt: Date;
  updatedAt: Date;
}

// Campaign types
export interface Campaign {
  id: number;
  organizationId: number;
  name: string;
  slug: string;
  description: string | null;
  goal: number | null;
  currency: string;
  startDate: Date;
  endDate: Date | null;
  isActive: boolean;
  coverImage: string | null;
  totalRaised: number;
  totalDonors: number;
  createdAt: Date;
  updatedAt: Date;
}

// Payout types
export type PayoutStatus = 'pending' | 'completed' | 'failed';

export interface Payout {
  id: number;
  organizationId: number;
  amount: number;
  currency: string;
  status: PayoutStatus;
  stripePayoutId: string | null;
  periodStart: Date;
  periodEnd: Date;
  createdAt: Date;
  updatedAt: Date;
}
