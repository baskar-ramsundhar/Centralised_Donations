'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

// Mock data for organizations
const MOCK_ORGANIZATIONS = [
  {
    id: 1,
    name: 'Global Water Foundation',
    slug: 'global-water-foundation',
    description: 'Providing clean water access to communities around the world.',
    category: 'Environment',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 125000,
    totalDonors: 1250,
  },
  {
    id: 2,
    name: 'Education For All',
    slug: 'education-for-all',
    description: 'Supporting education initiatives in underserved communities.',
    category: 'Education',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 98000,
    totalDonors: 876,
  },
  {
    id: 3,
    name: 'Animal Rescue Network',
    slug: 'animal-rescue-network',
    description: 'Rescuing and rehabilitating animals in need.',
    category: 'Animals',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 75000,
    totalDonors: 650,
  },
  {
    id: 4,
    name: 'Hunger Relief Initiative',
    slug: 'hunger-relief-initiative',
    description: 'Fighting hunger and food insecurity worldwide.',
    category: 'Humanitarian',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 112000,
    totalDonors: 980,
  },
  {
    id: 5,
    name: 'Climate Action Coalition',
    slug: 'climate-action-coalition',
    description: 'Advocating for policies to address climate change.',
    category: 'Environment',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 87000,
    totalDonors: 720,
  },
  {
    id: 6,
    name: 'Healthcare Access Project',
    slug: 'healthcare-access-project',
    description: 'Expanding healthcare access to underserved populations.',
    category: 'Health',
    logo: '/placeholder.png',
    coverImage: '/placeholder.png',
    totalDonations: 103000,
    totalDonors: 890,
  },
];

// Mock data for categories
const CATEGORIES = [
  { id: 1, name: 'All', slug: 'all' },
  { id: 2, name: 'Environment', slug: 'environment' },
  { id: 3, name: 'Education', slug: 'education' },
  { id: 4, name: 'Health', slug: 'health' },
  { id: 5, name: 'Humanitarian', slug: 'humanitarian' },
  { id: 6, name: 'Animals', slug: 'animals' },
  { id: 7, name: 'Arts & Culture', slug: 'arts-culture' },
];

export default function DiscoverPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter organizations based on category and search query
  const filteredOrganizations = MOCK_ORGANIZATIONS.filter((org) => {
    const matchesCategory = selectedCategory === 'all' || org.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = org.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          org.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Discover Organizations</h1>
          <p className="text-xl max-w-3xl">
            Browse through our curated list of verified non-profit organizations and find causes that align with your values.
          </p>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Search organizations..."
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex-1">
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {CATEGORIES.map((category) => (
                  <option key={category.id} value={category.slug}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 mb-8">
          {CATEGORIES.map((category) => (
            <button
              key={category.id}
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                selectedCategory === category.slug
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
              onClick={() => setSelectedCategory(category.slug)}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredOrganizations.length} organizations
          </p>
        </div>

        {/* Organizations Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {filteredOrganizations.map((org) => (
            <div key={org.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 bg-gray-200"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gray-300 rounded-full mr-3"></div>
                  <div>
                    <h3 className="text-xl font-semibold">{org.name}</h3>
                    <span className="text-sm text-gray-500">{org.category}</span>
                  </div>
                </div>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {org.description}
                </p>
                <div className="flex justify-between text-sm text-gray-500 mb-4">
                  <span>${(org.totalDonations / 1000).toFixed(1)}K raised</span>
                  <span>{org.totalDonors} donors</span>
                </div>
                <div className="flex gap-2">
                  <Button asChild className="flex-1">
                    <Link href={`/donate/${org.slug}`}>
                      Donate
                    </Link>
                  </Button>
                  <Button asChild variant="outline" className="flex-1">
                    <Link href={`/organizations/${org.slug}`}>
                      Learn More
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex justify-center mb-12">
          <nav className="flex items-center gap-1">
            <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">
              Previous
            </button>
            <button className="px-3 py-1 rounded bg-blue-600 text-white">1</button>
            <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">
              2
            </button>
            <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">
              3
            </button>
            <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">
              Next
            </button>
          </nav>
        </div>
      </div>
    </div>
  );
}
