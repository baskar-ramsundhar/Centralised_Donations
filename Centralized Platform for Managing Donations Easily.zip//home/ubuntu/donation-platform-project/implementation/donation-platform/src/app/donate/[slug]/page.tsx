'use client';

import React, { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

// Mock organization data
const MOCK_ORGANIZATION = {
  id: 1,
  name: 'Global Water Foundation',
  slug: 'global-water-foundation',
  description: 'Providing clean water access to communities around the world.',
  mission: 'Our mission is to ensure that every person on the planet has access to clean, safe drinking water. We work with local communities to implement sustainable water solutions and educate about water conservation.',
  category: 'Environment',
  logo: '/placeholder.png',
  coverImage: '/placeholder.png',
  website: 'https://example.org',
  email: 'contact@example.org',
  phoneNumber: '+1 (555) 123-4567',
  totalDonations: 125000,
  totalDonors: 1250,
  recurringDonors: 450,
};

// Donation amount options
const DONATION_AMOUNTS = [10, 25, 50, 100, 250, 500];
const DONATION_INTERVALS = [
  { value: 'one-time', label: 'One-time' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'annually', label: 'Annually' },
];

export default function DonatePage() {
  const params = useParams();
  const organizationSlug = params.slug;
  
  // In a real app, we would fetch the organization data based on the slug
  const organization = MOCK_ORGANIZATION;
  
  // Donation form state
  const [selectedAmount, setSelectedAmount] = useState<number>(25);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [donationInterval, setDonationInterval] = useState<string>('one-time');
  const [coverFees, setCoverFees] = useState<boolean>(true);
  const [isAnonymous, setIsAnonymous] = useState<boolean>(false);
  const [note, setNote] = useState<string>('');
  
  // Calculate platform fee (3% of donation amount)
  const donationAmount = customAmount ? parseFloat(customAmount) : selectedAmount;
  const platformFee = donationAmount * 0.03;
  const stripeFee = donationAmount * 0.029 + 0.30;
  const totalAmount = coverFees ? donationAmount + platformFee + stripeFee : donationAmount;
  
  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };
  
  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '' || /^\d+(\.\d{0,2})?$/.test(value)) {
      setCustomAmount(value);
      setSelectedAmount(0);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, we would process the donation through Stripe here
    console.log({
      organizationId: organization.id,
      amount: donationAmount,
      interval: donationInterval,
      coverFees,
      isAnonymous,
      note,
      totalAmount,
    });
    
    // Redirect to payment processing page
    // window.location.href = `/donate/${organizationSlug}/payment`;
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Organization Header */}
      <div className="bg-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-6">
            <div className="w-16 h-16 bg-white rounded-full mr-4"></div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">{organization.name}</h1>
              <p className="text-blue-100">{organization.category}</p>
            </div>
          </div>
          <p className="text-xl max-w-3xl">
            {organization.description}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Donation Form */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h2 className="text-2xl font-bold mb-6">Make a Donation</h2>
              
              <form onSubmit={handleSubmit}>
                {/* Donation Amount */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">
                    Select Donation Amount
                  </label>
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {DONATION_AMOUNTS.map((amount) => (
                      <button
                        key={amount}
                        type="button"
                        className={`py-2 px-4 rounded-md ${
                          selectedAmount === amount && !customAmount
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                        }`}
                        onClick={() => handleAmountSelect(amount)}
                      >
                        ${amount}
                      </button>
                    ))}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="text"
                      placeholder="Custom Amount"
                      className={`w-full pl-8 pr-4 py-2 border ${
                        customAmount ? 'border-blue-500' : 'border-gray-300'
                      } rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500`}
                      value={customAmount}
                      onChange={handleCustomAmountChange}
                    />
                  </div>
                </div>
                
                {/* Donation Interval */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">
                    Donation Frequency
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {DONATION_INTERVALS.map((interval) => (
                      <button
                        key={interval.value}
                        type="button"
                        className={`py-2 px-4 rounded-md ${
                          donationInterval === interval.value
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                        }`}
                        onClick={() => setDonationInterval(interval.value)}
                      >
                        {interval.label}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Cover Fees */}
                <div className="mb-6">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="coverFees"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={coverFees}
                      onChange={() => setCoverFees(!coverFees)}
                    />
                    <label htmlFor="coverFees" className="ml-2 block text-gray-700">
                      Cover transaction fees (${(platformFee + stripeFee).toFixed(2)})
                    </label>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 ml-6">
                    This ensures the organization receives your full donation amount.
                  </p>
                </div>
                
                {/* Anonymous Donation */}
                <div className="mb-6">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="anonymous"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={isAnonymous}
                      onChange={() => setIsAnonymous(!isAnonymous)}
                    />
                    <label htmlFor="anonymous" className="ml-2 block text-gray-700">
                      Make this donation anonymous
                    </label>
                  </div>
                </div>
                
                {/* Note */}
                <div className="mb-6">
                  <label htmlFor="note" className="block text-gray-700 font-medium mb-2">
                    Add a Note (Optional)
                  </label>
                  <textarea
                    id="note"
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Share why you're supporting this organization..."
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                  ></textarea>
                </div>
                
                {/* Summary */}
                <div className="bg-gray-50 p-4 rounded-md mb-6">
                  <div className="flex justify-between mb-2">
                    <span>Donation Amount:</span>
                    <span>${donationAmount.toFixed(2)}</span>
                  </div>
                  {coverFees && (
                    <>
                      <div className="flex justify-between mb-2 text-sm text-gray-600">
                        <span>Platform Fee (3%):</span>
                        <span>${platformFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between mb-2 text-sm text-gray-600">
                        <span>Payment Processing Fee:</span>
                        <span>${stripeFee.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between font-bold pt-2 border-t border-gray-200">
                    <span>Total:</span>
                    <span>${totalAmount.toFixed(2)}</span>
                  </div>
                </div>
                
                {/* Submit Button */}
                <Button type="submit" className="w-full py-3 text-lg">
                  {donationInterval === 'one-time' 
                    ? `Donate $${totalAmount.toFixed(2)}` 
                    : `Donate $${totalAmount.toFixed(2)} ${donationInterval}`}
                </Button>
                
                <p className="text-sm text-gray-500 text-center mt-4">
                  By proceeding, you agree to our <Link href="/terms" className="text-blue-600 hover:underline">Terms of Service</Link> and <Link href="/privacy" className="text-blue-600 hover:underline">Privacy Policy</Link>.
                </p>
              </form>
            </div>
          </div>
          
          {/* Organization Info */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-bold mb-4">About {organization.name}</h3>
              <p className="text-gray-700 mb-4">
                {organization.mission}
              </p>
              <div className="border-t border-gray-200 pt-4 mt-4">
                <div className="flex items-center mb-2">
                  <span className="text-gray-600 w-24">Website:</span>
                  <a href={organization.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                    {organization.website.replace(/^https?:\/\//, '')}
                  </a>
                </div>
                <div className="flex items-center mb-2">
                  <span className="text-gray-600 w-24">Email:</span>
                  <a href={`mailto:${organization.email}`} className="text-blue-600 hover:underline">
                    {organization.email}
                  </a>
                </div>
                <div className="flex items-center">
                  <span className="text-gray-600 w-24">Phone:</span>
                  <span>{organization.phoneNumber}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold mb-4">Impact</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-md text-center">
                  <div className="text-2xl font-bold text-blue-700">
                    ${(organization.totalDonations / 1000).toFixed(1)}K
                  </div>
                  <div className="text-sm text-gray-600">Total Raised</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-md text-center">
                  <div className="text-2xl font-bold text-blue-700">
                    {organization.totalDonors}
                  </div>
                  <div className="text-sm text-gray-600">Total Donors</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-md text-center">
                  <div className="text-2xl font-bold text-blue-700">
                    {organization.recurringDonors}
                  </div>
                  <div className="text-sm text-gray-600">Recurring Donors</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-md text-center">
                  <div className="text-2xl font-bold text-blue-700">
                    Verified
                  </div>
                  <div className="text-sm text-gray-600">Status</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
