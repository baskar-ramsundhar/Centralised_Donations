# Project Structure

The donation platform will be organized with the following directory structure:

```
/src
  /app                     # Next.js App Router
    /api                   # API routes
      /auth                # Authentication endpoints
      /donations           # Donation processing endpoints
      /organizations       # Organization management endpoints
      /stripe              # Stripe Connect webhooks and endpoints
      /subscriptions       # Subscription management endpoints
    /dashboard             # Dashboard pages
      /admin               # Platform admin dashboard
      /donor               # Donor dashboard
      /organization        # Organization dashboard
    /discover              # Organization discovery pages
    /donate                # Donation flow pages
    /(marketing)           # Marketing/public pages
      /about
      /contact
      /faq
      /privacy
      /terms
  /components              # Reusable React components
    /common                # Common UI components
    /dashboard             # Dashboard-specific components
    /donation              # Donation-related components
    /forms                 # Form components
    /layout                # Layout components
    /ui                    # UI library components
  /hooks                   # Custom React hooks
  /lib                     # Utility functions and libraries
    /auth                  # Authentication utilities
    /db                    # Database utilities
    /stripe                # Stripe Connect utilities
    /validation            # Form validation utilities
  /models                  # Database models
  /types                   # TypeScript type definitions
```

This structure follows Next.js best practices and organizes code by feature and responsibility.
