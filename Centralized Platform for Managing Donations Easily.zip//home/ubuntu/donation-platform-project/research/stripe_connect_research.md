# Stripe Connect Research

## Overview
Stripe Connect is a platform that allows businesses to facilitate payments between multiple parties. It's ideal for our donation platform as it can handle the complex payment flows between donors, non-profit organizations, and our platform.

## Key Features

### Charge Types
Stripe Connect offers three main charge types:

1. **Direct Charges**
   - Charges are created directly on the connected account (non-profit organization)
   - Platform can add an application fee
   - Connected account's balance increases with every charge
   - Connected account is debited for refunds and chargebacks
   - Best for: Software as a service platforms

2. **Destination Charges**
   - Charges are created on the platform and immediately transferred to connected accounts
   - Platform decides how much of the funds are transferred
   - Platform account is debited for Stripe fees, refunds, and chargebacks
   - Best for: Marketplaces

3. **Separate Charges and Transfers**
   - Charges are created on the platform and can be split between multiple connected accounts
   - Useful when you don't know the specific recipient at time of charge
   - Platform account is debited for Stripe fees, refunds, and chargebacks
   - Best for: Complex payment flows with multiple recipients

### Subscription Management
Stripe Connect supports subscription management for recurring donations:

- Can create subscriptions from end customers to connected accounts
- Can use either direct charges or destination charges
- Supports flat-rate, per-seat, and usage-based pricing models
- Handles automatic billing and payment collection

### Onboarding
Stripe Connect provides multiple onboarding options:

- Stripe-hosted onboarding forms
- Customizable components that can be embedded in our website
- API-based onboarding with full control over UI

### Payment Processing
- Supports 135+ currencies
- Dynamically surfaces 40+ payment methods
- Supports digital wallets (Apple Pay, Google Pay)
- Handles sales tax, VAT, and GST in 40+ countries

### Platform Tools
- Monetization options
- Risk management
- Tax reporting (automated 1099 form generation in the US)
- Analytics and reporting

## Recommended Approach for Donation Platform
For our donation platform, the **Destination Charges** model appears most suitable because:

1. It allows our platform to be the merchant of record
2. We can handle all Stripe fees, refunds, and chargebacks centrally
3. We can transfer funds to non-profit organizations after taking our platform fee
4. It provides a more consistent experience for donors

For subscription management, we should use the destination charges approach to create subscriptions, which will allow us to:
1. Handle recurring donations efficiently
2. Maintain control over the donor relationship
3. Provide detailed reporting to both donors and organizations
